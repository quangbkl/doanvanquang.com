<?php
	$server = "sql210.byethost24.com";
	$username = "b24_21134494";
	$password = "quangdev5$";
	$database = "b24_21134494_quang";
?>